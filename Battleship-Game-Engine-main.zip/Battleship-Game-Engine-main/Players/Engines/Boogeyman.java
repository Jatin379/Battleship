package Players.Engines;

public class Boogeyman extends BattleshipEngine {

    @Override
    public void placeShip(int shipIndex) {

    }

    @Override
    public String fireASalvo() {
        return null;
    }

}//end of class
